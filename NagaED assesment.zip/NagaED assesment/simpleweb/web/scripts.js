document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
  
    // Input validation
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
  
    if (name === "" || email === "" || message === "") {
      alert("Please fill out all fields.");
      return;
    }
  
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
      alert("Please enter a valid email address.");
      return;
    }
  
    // Success message
    document.getElementById("successMessage").innerText = "Thank you for contacting us!";
  
    // Log input data to the console
    console.log({
      name: name,
      email: email,
      message: message
    });
  
    // Clear the form
    document.getElementById("contactForm").reset();
  });
  