const express = require("express");
const app = express();
app.use(express.json());

let courses = [];

// Get all courses
app.get("/courses", (req, res) => {
  res.json(courses);
});

// Add a new course
app.post("/courses", (req, res) => {
  const newCourse = {
    id: courses.length + 1,
    title: req.body.title,
    description: req.body.description,
    duration: req.body.duration
  };
  courses.push(newCourse);
  res.status(201).json(newCourse);
});

// Update a course by ID
app.put("/courses/:id", (req, res) => {
  const course = courses.find(c => c.id === parseInt(req.params.id));
  if (!course) return res.status(404).send("Course not found");

  course.title = req.body.title;
  course.description = req.body.description;
  course.duration = req.body.duration;
  res.json(course);
});

// Delete a course by ID
app.delete("/courses/:id", (req, res) => {
  const courseIndex = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (courseIndex === -1) return res.status(404).send("Course not found");

  const deletedCourse = courses.splice(courseIndex, 1);
  res.json(deletedCourse);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
